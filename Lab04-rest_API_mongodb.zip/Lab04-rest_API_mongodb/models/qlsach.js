const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  tenSach: { type: String, required: true },
  moTa: { type: String, required: true, unique: true },
  urlHinh: { type: String, required: true },
  gia: { type: Number, required: true },
  idLoai: { type: String, required: true },
  anHien: { type: Boolean, required: true },
  capNhat: { type: Date, default: Date.now },
});

const User = mongoose.model('qlsach', userSchema);

module.exports = User;
