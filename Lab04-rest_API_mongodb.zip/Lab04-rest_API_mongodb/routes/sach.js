const express = require('express');
const User = require('../models/qlsach');
const router = express.Router();

function getFormattedDate() {
  const date = new Date();
  
  // Múi giờ Việt Nam là UTC+7, thêm 7 giờ vào
  const vietnamTime = new Date(date.getTime() + 7 * 60 * 60 * 1000);
  
  const yy = vietnamTime.getFullYear().toString().slice(-2);
  const mm = (vietnamTime.getMonth() + 1).toString().padStart(2, '0');
  const dd = vietnamTime.getDate().toString().padStart(2, '0');
  const hour = vietnamTime.getHours().toString().padStart(2, '0');
  const min = vietnamTime.getMinutes().toString().padStart(2, '0');
  const sec = vietnamTime.getSeconds().toString().padStart(2, '0');
  
  const formattedDate = `${yy}/${mm}/${dd} ${hour}:${min}:${sec}`;
  
  return {
    formattedDate,  
    dateObject: vietnamTime 
  };
}


// Lấy danh sách truyện
router.get('/', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Thêm thông tin mới
router.post('/', async (req, res) => {
  const formattedDate = getFormattedDate(); 
  
  const user = new User({
    tenSach: req.body.tenSach,
    moTa: req.body.moTa,
    urlHinh: req.body.urlHinh,
    capNhat: formattedDate.dateObject, 
    gia: req.body.gia,
    idLoai: req.body.idLoai,
    anHien: req.body.anHien,
  });

  try {
    const newUser = await user.save();
    res.status(201).json(newUser);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});


// Cập nhật thông tin truyện theo ID
router.put('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'Không tìm thấy người dùng' });
    }

    // Cập nhật các trường cần thiết
    user.tenSach = req.body.tenSach || user.tenSach;
    user.moTa = req.body.moTa || user.moTa;
    user.urlHinh = req.body.urlHinh || user.urlHinh;
    user.capNhat = req.body.capNhat ? new Date(req.body.capNhat) : user.capNhat; // Chuyển đổi capNhat thành Date
    user.gia = req.body.gia || user.gia;
    user.idLoai = req.body.idLoai || user.idLoai;
    user.anHien = req.body.anHien || user.anHien;

    const updatedUser = await user.save();
    res.json(updatedUser);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Xóa truyện theo ID
router.delete('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'Không tìm thấy thông tin truyện' });
    }

    // Sử dụng findByIdAndDelete để xóa người dùng
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'Thông tin truyện đã được xóa' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
