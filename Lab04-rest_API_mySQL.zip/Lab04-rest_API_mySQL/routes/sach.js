const express = require('express');
const db = require('../config/db'); // Kết nối MySQL từ db.js
const router = express.Router();

// Lấy danh sách sách
router.get('/', async (req, res) => {
  try {
    const [results] = await db.query('SELECT * FROM qlsach');
    res.json(results);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Thêm sách mới
router.post('/', async (req, res) => {
  const { tenSach, moTa, urlHinh, capNhat, gia, idLoai, anHien } = req.body;
  try {
    const [result] = await db.query(
      'INSERT INTO qlsach (tenSach, moTa, urlHinh, capNhat, gia, idLoai, anHien) VALUES (?, ?, ?, ?, ?, ?, ?)', 
      [tenSach, moTa, urlHinh, capNhat, gia, idLoai, anHien]
    );
    res.status(201).json({ message: 'Sách đã được thêm', bookId: result.insertId });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Cập nhật sách theo ID
router.put('/:id', async (req, res) => {
  const { tenSach, moTa, urlHinh, capNhat, gia, idLoai, anHien } = req.body;
  const bookId = req.params.id;
  try {
    const [result] = await db.query(
      'UPDATE books SET tenSach = ?, moTa = ?, urlHinh = ?, capNhat = ?, gia = ?, idLoai = ?, anHien = ? WHERE id = ?', 
      [tenSach, moTa, urlHinh, capNhat, gia, idLoai, anHien, bookId]
    );
    res.json({ message: 'Sách đã được cập nhật' });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Xóa sách theo ID
router.delete('/:id', async (req, res) => {
  const bookId = req.params.id;
  try {
    await db.query('DELETE FROM books WHERE id = ?', [bookId]);
    res.json({ message: 'Sách đã được xóa' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
