const express = require('express');
const mysql = require('mysql2');  // Sử dụng mysql2 để hỗ trợ promises
const bodyParser = require('body-parser');
const sachRoute = require('./routes/sach');

const app = express();
const PORT = 3000;

// Thiết lập kết nối MySQL sử dụng Pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',        
  password: '',
  database: 'sach',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Kết nối MySQL sử dụng promises
pool.getConnection((err, connection) => {
  if (err) {
    console.error('Không thể kết nối MySQL', err);
  } else {
    console.log('Kết nối MySQL thành công');
    connection.release(); // Giải phóng kết nối sau khi kiểm tra
  }
});

// Middleware
app.use(bodyParser.json());

// Routes
app.use('/api/sach', sachRoute);

// Route mặc định
app.get('/', (req, res) => {
    res.send('API is running');
});

// Lắng nghe server
app.listen(PORT, () => {
  console.log(`Server đang chạy tại http://localhost:${PORT}`);
});

// Xuất kết nối pool để sử dụng trong các file route (sử dụng promise)
module.exports = pool.promise();
